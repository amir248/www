<?php $plug = "Заглушка"; ?>
  <img class='logo' src="images/logo.png">
<ul>
    <li><a href="#">Главная</a></li>
    <li><a href="#">Животные</a></li>
    <li><a href="#">Приюты</a></li>
    <li><a href="#">Волонтёры</a></li>
    <li><a href="#">Новости</a></li>
    <li><a href="#">Стать волонтёром</a> </li>
    <li><a href="#">О нас</a> </li>
</ul>
<button>Личный кабинет</button>
