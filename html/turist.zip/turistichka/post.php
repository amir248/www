<?php
// подключение к базе данных
if($_SERVER['SERVER_NAME']=="localhost"){
  $servername = "localhost"; // Сейчас работает это!
  $database = "turist";
  $username = "root";
  $password = "password";
}else{
  $servername = "https://site.ru/"; // если бд на другом серваетк
  $database = "site";
  $username = "site";
  $password = "password";
}
// переменные поста!
$title = $_POST['title'];
$text = $_POST['text'];
$url=$_POST['url'];


$connect = mysqli_connect($servername, $username, $password,$database);
$posText=mysqli_query($connect, "SELECT * FROM `home` ORDER BY `id`, `title`,`text`, `url`  ASC");

if(isset($_POST["button"])){
  $connect = mysqli_connect($servername, $username, $password,$database);
  if(!$connect){
    die("Connection failed: " . mysqli_connect_error());
  }else{
    echo "<br>connection Успешно! Ура!!!";
  }
mysqli_query($connect, "SET NAMES utf8");
mysqli_query($connect, "INSERT INTO `table-page` (`id`, `title`, `text`, `url`) VALUES (NULL, '$title',  '$text', '$url')");
mysqli_close($connect);
}

?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <form action="post.php" method="post">
      <input name="title">
      <input name="text">
      <input name="url">
      <button name="button">otpravit</button>
    </form>
  </body>
</html>
