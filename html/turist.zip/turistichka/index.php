<?php
// подключение к базе данных
if($_SERVER['SERVER_NAME']=="localhost"){
  $servername = "localhost"; // Сейчас работает это!
  $database = "turist";
  $username = "root";
  $password = "password";
}else{
  $servername = "localhost"; // если бд на другом серваетк
  $database = "id17909737_turist";
  $username = "id17909737_turist999";
  $password = "xf1WG>B$4+7b}Z_k";
}
$connect = mysqli_connect($servername, $username, $password,$database);
$pages=mysqli_query($connect, "SELECT * FROM `table-page` ORDER BY `id`, `title`,`text`, `url`  ASC");

$allPages=mysqli_fetch_all($pages);

// for($i=0;$i<count($allPages);$i++){
$post=$allPages[url];
print_r($post);

  foreach($allPages as $pages){
    // echo '<pre>';
    // print_r($allPages);
    // echo '</pre>';
    // $posts = $allPages[$i][3];

  if(isset($_GET[url1])==$allPages[0][3]){
    echo $post[1][3];
    $zag= $allPages[0][1];
    $posts = $allPages[0][2];
    $mailer = '<div style="display:flex; justify-content:center; align-items:center; flex-wrap:wrap;">
        <p style="display:flex; justify-content:space-between; align-items:center; flex-direction:column; max-width:100%; width:200px;height:330px; background:rgba(150,150,0,0.5);border-radius:5px; margin:1%;"><img src="img/ok.jpg" style="width:200px; border-top-right-radius:5px;border-top-left-radius:5px;"><span style="margin:3%;">Тур, путевка, все такое</span><button style="width:150px;height:50px; background:coral;border-radius:5px; color:white;text-shadow:1px 1px 3px black;">Взять путь</button></p>
        <p style="display:flex; justify-content:space-between; align-items:center; flex-direction:column; max-width:100%; width:200px;height:330px; background:rgba(150,150,0,0.5);border-radius:5px; margin:1%;"><img src="img/ok.jpg" style="width:200px; border-top-right-radius:5px;border-top-left-radius:5px;"><span style="margin:3%;">Тур, путевка, все такое</span><button style="width:150px;height:50px; background:coral;border-radius:5px; color:white;text-shadow:1px 1px 3px black;">Взять путь</button></p>  <p style="display:flex; justify-content:space-between; align-items:center; flex-direction:column; max-width:100%; width:200px;height:330px; background:rgba(150,150,0,0.5);border-radius:5px; margin:1%;"><img src="img/ok.jpg" style="width:200px; border-top-right-radius:5px;border-top-left-radius:5px;"><span style="margin:3%;">Тур, путевка, все такое</span><button style="width:150px;height:50px; background:coral;border-radius:5px; color:white;text-shadow:1px 1px 3px black;">Взять путь</button></p>

        <p style="display:flex; justify-content:space-between; align-items:center; flex-direction:column; max-width:100%; width:200px;height:330px; background:rgba(150,150,0,0.5);border-radius:5px; margin:1%;"><img src="img/ok.jpg" style="width:200px; border-top-right-radius:5px;border-top-left-radius:5px;"><span style="margin:3%;">Тур, путевка, все такое</span><button style="width:150px;height:50px; background:coral;border-radius:5px; color:white;text-shadow:1px 1px 3px black;">Взять путь</button></p>
        <p style="display:flex; justify-content:space-between; align-items:center; flex-direction:column; max-width:100%; width:200px;height:330px; background:rgba(150,150,0,0.5);border-radius:5px; margin:1%;"><img src="img/ok.jpg" style="width:200px; border-top-right-radius:5px;border-top-left-radius:5px;"><span style="margin:3%;">Тур, путевка, все такое</span><button style="width:150px;height:50px; background:coral;border-radius:5px; color:white;text-shadow:1px 1px 3px black;">Взять путь</button></p>  <p style="display:flex; justify-content:space-between; align-items:center; flex-direction:column; max-width:100%; width:200px;height:330px; background:rgba(150,150,0,0.5);border-radius:5px; margin:1%;"><img src="img/ok.jpg" style="width:200px; border-top-right-radius:5px;border-top-left-radius:5px;"><span style="margin:3%;">Тур, путевка, все такое</span><button style="width:150px;height:50px; background:coral;border-radius:5px; color:white;text-shadow:1px 1px 3px black;">Взять путь</button></p>

        <p style="display:flex; justify-content:space-between; align-items:center; flex-direction:column; max-width:100%; width:200px;height:330px; background:rgba(150,150,0,0.5);border-radius:5px; margin:1%;"><img src="img/ok.jpg" style="width:200px; border-top-right-radius:5px;border-top-left-radius:5px;"><span style="margin:3%;">Тур, путевка, все такое</span><button style="width:150px;height:50px; background:coral;border-radius:5px; color:white;text-shadow:1px 1px 3px black;">Взять путь</button></p>
        <p style="display:flex; justify-content:space-between; align-items:center; flex-direction:column; max-width:100%; width:200px;height:330px; background:rgba(150,150,0,0.5);border-radius:5px; margin:1%;"><img src="img/ok.jpg" style="width:200px; border-top-right-radius:5px;border-top-left-radius:5px;"><span style="margin:3%;">Тур, путевка, все такое</span><button style="width:150px;height:50px; background:coral;border-radius:5px; color:white;text-shadow:1px 1px 3px black;">Взять путь</button></p>  <p style="display:flex; justify-content:space-between; align-items:center; flex-direction:column; max-width:100%; width:200px;height:330px; background:rgba(150,150,0,0.5);border-radius:5px; margin:1%;"><img src="img/ok.jpg" style="width:200px; border-top-right-radius:5px;border-top-left-radius:5px;"><span style="margin:3%;">Тур, путевка, все такое</span><button style="width:150px;height:50px; background:coral;border-radius:5px; color:white;text-shadow:1px 1px 3px black;">Взять путь</button></p>
      </div>';
  }else if(isset($_GET[url2])==$allPages[1][3]){
    $zag= $allPages[1][1];
    $posts = $allPages[1][2];
    // header('Location: index.php?'.url[$i]);
  }else if(isset($_GET[url3])==$allPages[2][3]){
    $zag= $allPages[2][1];
    $posts = $allPages[2][2];
    $mailer = '  <div style="display:flex;justify-content:center;align-items:center;">
        <script type="text/javascript" charset="utf-8" async src="https://api-maps.yandex.ru/services/constructor/1.0/js/?um=constructor%3A7dce99ce1862cd51981ebb34abb8cafd3ec86e0f7daeff719313ba9bff01ba0d&amp;width=100%25&amp;height=390&amp;lang=ru_RU&amp;scroll=true"></script>
      </div>';
    // header('Location: index.php?'.url[$i]);
  }else if(isset($_GET[url4])==$allPages[3][3]){
    $zag= $allPages[3][1];
    $posts = $allPages[3][2];

    // header('Location: index.php?'.url[$i]);
  }else if(isset($_GET[url5])==$allPages[4][3]){
    $zag= $allPages[4][1];
    $posts = $allPages[4][2];

    // header('Location: index.php?'.url[$i]);
  }else if(!$_GET){
    // echo "none Get<br>";
    $mailer= '<div style="max-width:100%; width:900px;">
    <picture><img src="img/travel.jpg" atl="travel"></picture></div>
    <div style="display:flex; justify-content:center;align-items:center; min-height:300px; max-width:100%; flex-wrap:wrap; width:900px;">

        <h3 style="width:800px;max-width:100%;">Отправить заявку</h3>
      <form action="mail.php" method="post">
        <input name="name" placeholder="Ваше имя" style="width:199px;height:45px;border-radius:3px;max-width:100%;">
        <input name="tel" placeholder="Введите ваш телефон" style="width:199px;height:45px;border-radius:3px;max-width:100%;">
        <input name="email" placeholder="Ваш email" style="width:199px;height:45px;border-radius:3px;max-width:100%;">
      </form>

      <button style="width:299px;height:45px; background:coral; border-radius:3px; color:white; text-shadow: 1px 1px 3px black;">Отправить</button>

    </div>';
  }else if($_GET[$post[1][3]]){
    // $allPages[$i][2] == $post[$i];
    echo "YYYYYYY";
}
  break; // спрыгивает из цикла, иначе повторяет один пост

}
// }
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
    <meta name="description" content="туристический сайт">
    <meta name='viewport' content="width=device-width,initial-scale=1"/>
    <link rel="stylesheet" href="style/style.css">
  </head>
  <body>
    <main>
      <div class='menuBurg'>
          <p id='burger'>
            <span class="menu1"></span>
            <span class="menu2"></span>
            <span class="menu3"></span>
          </p>
      </div>
      <div class='menu'>
      <nav>
        <a href="index.php"><ul>home</ul></a>
        <a href="index.php?url1"><ul>Туры</ul></a>
        <a href="index.php?url2"><ul>Контакты</ul></a>
        <a href="index.php?url3"><ul>Карта</ul></a>
        <a href="index.php?url4"><ul>Отзовы</ul></a>
      </nav>
    </div>
      <article>

        <h1 style="color:coral;text-shadow:black 1px 1px 3px;">Туристическая организация.</h1>
        <p><?= $zag ?></p>

        <p><?= $posts ?></p>

        <!-- ОТПРАВКА формф для мыла будет тут -->
        <p><?= $mailer ?></p>

        <script src="menu.js"></script>
      </article>
    </main>
  </body>
</html>
<?php

 ?>
