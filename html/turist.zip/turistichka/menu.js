let countClick=+0;
document.querySelector('#burger').addEventListener('click',()=>{
  countClick++;
  if(countClick==1){
    document.querySelector('.menu1').style.cssText=`
    background:red;
    transform:rotate(-45deg);
    margin:0;
    `;
    document.querySelector('.menu2').style.cssText=`display:none`;
    document.querySelector('.menu3').style.cssText=`background:red;
    background:red;
    transform:rotate(45deg);
    margin:0;
    `;
    // document.querySelector('.menuBurg').style.cssText=`
    // position:absolute;
    // background:white;
    // height:100vh;
    // `
  }else if(countClick == 2){
    document.querySelector('.menu1').style.cssText=`background:green`;
    document.querySelector('.menu2').style.cssText=`display:block`;
    document.querySelector('.menu3').style.cssText=`background:green`;
    countClick=0;
  }else{
    console.log("Yyyyy!!!");
  }
});
