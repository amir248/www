<?= include "parts/_header.php"?>
<div class="container-xxl">
    <?= include "parts/_homeslider.php"?>
    <?= include "parts/_homeblockcharity.php"?>
#WORK_AREA#
</div>
<?=include "parts/_footer.php"?>
