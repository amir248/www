<?php include "parts/_header.php"?>
<div class="container-xxl">
    <?php include "parts/_homeslider.php"?>
    <?php include "parts/_homeblockcharity.php"?>
#WORK_AREA#
</div>
<?php include "parts/_footer.php"?>
