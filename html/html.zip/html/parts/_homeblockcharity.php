<div class="home-charity">
    <div class="home-charity-wrapper">
    </div>
</div>